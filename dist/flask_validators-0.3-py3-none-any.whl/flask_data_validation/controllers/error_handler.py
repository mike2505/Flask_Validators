class ErrorHandler:
    @staticmethod
    def handle_validation_error(error):
        # Here would be the code to handle validation errors
        pass